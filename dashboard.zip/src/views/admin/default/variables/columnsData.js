export const columnsDataCheck = [
  {
    Header: "IMAGE",
    accessor:"image",
  },
  {
    Header: "NAME",
    accessor: "name",
  },
  {
    Header: "STOCK",
    accessor: "stock",
  },
  {
    Header: "PRICE",
    accessor: "price",
  },
  {
    Header: "TOTAL SALES",
    accessor: "total sales",
  },
];
export const columnsDataComplex = [
  {
    Header: "NAME",
    accessor: "name",
  },
  {
    Header: "STATUS",
    accessor: "status",
  },
  {
    Header: "DATE",
    accessor: "date",
  },
  {
    Header: "PROGRESS",
    accessor: "progress",
  },
];
